"""Guess-My-Word is a game where the player has to guess a word.
Author: <Arthur D'avila de Paiva>
Student ID: 20070861"""

import random
import os
import sys
import platform

MISS = "0"  #_-.: letter not found ⬜
MISPLACED = "1"  # O, ?: letter in wrong place 🟨
EXACT = "2"  # X, +: right letter, right place 🟩

ALL_WORDS_FILE = './word-bank/all_words.txt'
TARGET_WORDS_FILE = './word-bank/target_words.txt'
RESULTS_FILE = 'score-save.txt'
valid_words = []


def play():
    game_title()
    """Code that controls the interactive game play"""
    # select a word of the day:
    target_word = get_target_word()
    # build a list of valid words (words that can be entered in the UI):
    valid_words = get_valid_words()
    # do the following in an iteration construct

    max_attempts = 6
    guess_count = 0
    fail = False
    while guess_count < max_attempts:
        guesses_left = 6
        guess_count += 1
        guess_word = ask_for_guess(valid_words)
        score = score_guess(guess_word, target_word)
        print("Result of your guess:")
        print(f"{format_score(guess_word, score)}\n")

        if is_correct(score):
            print(f"Congratulations! You got the word in {guess_count} tries.")

            break
        else:
            guesses_left = guesses_left - guess_count
            print(f"{guesses_left} guess(es) left.")
        # end iteration

    if guess_count == max_attempts:
        print(f"Bad Luck, the word was '{target_word.upper()}'.")
        fail = True

    if fail:
        save_score("Miss")
    else:
        save_score(str(guess_count))

    input()
    menu()


def is_correct(score):
    """Checks if the score is entirely correct and returns True if it is
    Examples:
    >>> is_correct((1,1,1,1,1))
    False
    >>> is_correct((2,2,2,2,1))
    False
    >>> is_correct((0,0,0,0,0))
    False
    >>> is_correct((2,2,2,2,2))
    True"""
    if score == (tuple(EXACT*5)):
        return True
    else:
        return False


def get_valid_words(file_path=ALL_WORDS_FILE):
    """returns a list containing all valid words.
    Note to test that the file is read correctly, use:
    >>> get_valid_words()[0]
    'aahed'
    >>> get_valid_words()[-1]
    'zymic'
    >>> get_valid_words()[10:15]
    ['abamp', 'aband', 'abase', 'abash', 'abask']
    """   

    # read words from files and return a list containing all words that can be entered as guesses

    file_guess = open(file_path)
        
    for line in file_guess:
        if line not in valid_words:
            line = line.strip()
            valid_words.append(line)

    file_guess.close()

    return valid_words


def get_target_word(file_path=TARGET_WORDS_FILE):
    """Picks a random word from a file of words

    Args:
        file_path (str): the path to the file containing the words

    Returns:
        str: a random word from the file

    How do you test that a random word chooser is choosing the correct words??
    Discuss in class!
    >>> get_target_word()
    'aback'
    >>> get_target_word()
    'zonal'
    """
    
    # read words from a file and return a random word (word of the day)

    file_target = open(file_path)
    target = random.choice(file_target.read().split())
    file_target.close()

    return target


def ask_for_guess(valid_words_list):
    """Requests a guess from the user directly from stdout/in
    Returns:
        str: the guess chosen by the user. Ensures guess is a valid word of correct length in lowercase
    """
    
    guess = input("Guess word: ").lower()

    while len(guess) != 5 or guess not in valid_words_list:
        if len(guess) != 5:
            print("Invalid length!\nPlease guess a 5 letter word")
        else:
            print("Word not valid!\nPlease guess valid word.")
        guess = input("Guess word: ").lower()

    return guess


def score_guess(guess, target_word):
    """given two strings of equal length, returns a tuple of ints representing the score of the guess
    against the target word (MISS, MISPLACED, or EXACT)
    Here are some example (will run as doctest):

    >>> score_guess('hello', 'hello')
    (2, 2, 2, 2, 2)
    >>> score_guess('drain', 'float')
    (0, 0, 1, 0, 0)
    >>> score_guess('hello', 'spams')
    (0, 0, 0, 0, 0)

    Try and pass the first few tests in the doctest before passing these tests.
    >>> score_guess('gauge', 'range')
    (0, 2, 0, 2, 2)
    >>> score_guess('melee', 'erect')
    (0, 1, 0, 1, 0)
    >>> score_guess('array', 'spray')
    (0, 0, 2, 2, 2)
    >>> score_guess('train', 'tenor')
    (2, 1, 0, 0, 1)
        """
    # You must use this convention as test automation will be validating your scorer

    result = [' '] * 5
    list_target = list(target_word)
    list_guess = list(guess)
    for letter_position, letter in enumerate(guess):
        if letter == target_word[letter_position]:
            result[letter_position] = EXACT
            list_guess[letter_position] = '#'
            list_target.remove(letter)

    for letter_position, letter in enumerate(list_guess):
        if letter != '#':
            if letter in list_target:
                result[letter_position] = MISPLACED
                list_guess[letter_position] = '#'
                list_target.remove(letter)

            else:
                result[letter_position] = MISS

    return tuple(result)


def help_section():
    """Provides help for the game"""
    game_title()
    print("\nHOW TO PLAY!")
    print("Guess the word of the day in 6 tries. ")
    print("Each guess must be a valid 5 letter word.\n")
    print("Examples: \n")
    print("H E L L O")
    print("+ _ _ ? _\n")
    print("+ means that the letter is in the word and in the correct spot.")
    print("? means that the letter is in the word but in the wrong spot.")
    print("_ means that the letter is not in the word.")
    print("Now you are ready to play :) \n")
    input()
    menu()


def format_score(guess, score):
    """Formats a guess with a given score as output to the terminal.
    The following is an example output (you can change it to meet your own creative ideas, 
    but be sure to update these examples)
    >>> print(format_score('hello', (0,0,0,0,0)))
    H E L L O
    _ _ _ _ _
    >>> print(format_score('hello', (0,0,0,1,1)))
    H E L L O
    _ _ _ ? ?
    >>> print(format_score('hello', (1,0,0,2,1)))
    H E L L O
    ? _ _ + ?
    >>> print(format_score('hello', (2,2,2,2,2)))
    H E L L O
    + + + + +"""

    guess_upper = guess.upper()
    guess_upper = " ".join(guess_upper)
    print(guess_upper)
    result = ""
    for item in score:
        if item == EXACT:
            result = result + "+ "
        elif item == MISPLACED:
            result = result + "? "
        else:
            result = result + "_ "

    return result.rstrip()


def menu():
    answer = ""
    while answer != "P" or answer != "H" or answer != "S" or answer != "Q":
        clear()
        game_title()
        print("P -> Play the game".center(100))
        print("H -> How to play".center(100))
        print("S -> Check score".center(100))
        print("Q -> Quit\n".center(100))
        answer = input().upper()

        if answer == "P":
            play()
        if answer == "H":
            help_section()
        if answer == "S":
            get_score()
        if answer == "Q":
            clear()
            sys.exit(0)


def game_title():
    clear()
    print("GUESS MY WORD\n\n".center(100))


def clear():
    current_platform = platform.system()
    if current_platform == "Windows":
        os.system('cls')
    elif current_platform == "Darwin" or current_platform == "Linux":
        os.system('clear')
    else:
        pass


def get_score():
    game_title()
    with open(RESULTS_FILE, "r") as file:
        read = file.read()
        print(read)
    input()
    menu()


def save_score(result):
    results = {}
    with open(RESULTS_FILE, "r") as file:
        lines = file.readlines()
        for line in lines:
            value = line.strip().split(":")
            if len(value) == 2:
                index, score = value
                results[index.strip()] = int(score.strip())

    if result in results:
        results[result] += 1

    with open(RESULTS_FILE, "w") as file:
        for index, score in results.items():
            file.write(f"{index}: {score}\n")


"""
def main(test=False):
    if test:
        import doctest
        return doctest.testmod()
    play()

if __name__ == '__main__':
    print(main(test=False))
"""

menu()
